from django.shortcuts import render, HttpResponse, redirect
# from home.models import Contact
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
# from blog.models import Post

# Create your views here.
def index(request):
    context = {
        "vish": "This is sent"
    }
    return render(request, "index.html", context)
    # return HttpResponse("this is homepage")

def about(request):
    return render(request, "about.html")
    # return HttpResponse("this is about")

def service(request):
    return HttpResponse("this is service")

def contact(request):
    return render(request, "contact.html")
    #  return HttpResponse("this is Contact")

def handelSignup(request):
    if request.method == "POST":
        # get the post
        username = request.POST['username']
        fname = request.POST['fname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        #Validation

        if pass1 != pass2:
            messages.error(request, "Please eneter same password")
            return redirect('/')
    
        #Create user
        myuser = User.objects.create_user(username, email, pass1)
        myuser.first_name = fname

        myuser.save()
        messages.success(request, "Congratulations! Your account has been created")
        return redirect('/')

    else:
        return HttpResponse('404 - Not Found')

def handlelogin(request):
    if request.method == "POST":
        loginusername = request.POST['loginusername']
        loginpassword = request.POST['loginpassword']

        user = authenticate(username=loginusername , password=loginpassword )

    if user is not None:
        login(request, user)
        messages.success(request, "Successfully Logged in")
        return redirect('home')
    else:
        messages.error(request, "Invalid username and password")
        return redirect('home')
        
    return HttpResponse('404 Not Found')

def handlelogout(request):
        logout(request)
        messages.success(request, "Successfully Logged out")
        return redirect('home')

        return HttpResponse('handlelogout')